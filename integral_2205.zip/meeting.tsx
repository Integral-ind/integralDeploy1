"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { PlusCircle, Trash2, Calendar, Users, Edit } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

interface MeetingNote {
  id: string
  title: string
  date: string
  attendees: string
  notes: string
  actionItems: string
  createdAt: string
}

export default function MeetingsPage() {
  const [meetings, setMeetings] = useState<MeetingNote[]>([])
  const [newMeeting, setNewMeeting] = useState<Omit<MeetingNote, "id" | "createdAt">>({
    title: "",
    date: new Date().toISOString().split("T")[0],
    attendees: "",
    notes: "",
    actionItems: "",
  })
  const [editingMeeting, setEditingMeeting] = useState<MeetingNote | null>(null)
  const [open, setOpen] = useState(false)
  const [editOpen, setEditOpen] = useState(false)
  const [viewOpen, setViewOpen] = useState(false)
  const [viewingMeeting, setViewingMeeting] = useState<MeetingNote | null>(null)
  const { toast } = useToast()

  // Load meetings from local storage on component mount
  useEffect(() => {
    const savedMeetings = localStorage.getItem("meetingNotes")
    if (savedMeetings) {
      try {
        setMeetings(JSON.parse(savedMeetings))
      } catch (error) {
        console.error("Failed to parse saved meetings", error)
      }
    }
  }, [])

  // Save meetings to local storage whenever they change
  useEffect(() => {
    localStorage.setItem("meetingNotes", JSON.stringify(meetings))
  }, [meetings])

  const handleAddMeeting = () => {
    if (!newMeeting.title) {
      toast({
        title: "Missing title",
        description: "Please provide a title for the meeting note",
        variant: "destructive",
      })
      return
    }

    const meeting: MeetingNote = {
      id: crypto.randomUUID(),
      title: newMeeting.title,
      date: newMeeting.date,
      attendees: newMeeting.attendees,
      notes: newMeeting.notes,
      actionItems: newMeeting.actionItems,
      createdAt: new Date().toISOString(),
    }

    setMeetings([...meetings, meeting])
    setNewMeeting({
      title: "",
      date: new Date().toISOString().split("T")[0],
      attendees: "",
      notes: "",
      actionItems: "",
    })
    setOpen(false)

    toast({
      title: "Meeting note added",
      description: "Your meeting note has been saved successfully",
    })
  }

  const handleUpdateMeeting = () => {
    if (!editingMeeting) return

    setMeetings(meetings.map((meeting) => (meeting.id === editingMeeting.id ? editingMeeting : meeting)))
    setEditingMeeting(null)
    setEditOpen(false)

    toast({
      title: "Meeting note updated",
      description: "Your meeting note has been updated successfully",
    })
  }

  const handleDeleteMeeting = (id: string) => {
    setMeetings(meetings.filter((meeting) => meeting.id !== id))

    toast({
      title: "Meeting note deleted",
      description: "Your meeting note has been deleted",
      variant: "destructive",
    })
  }

  const handleEditMeeting = (meeting: MeetingNote) => {
    setEditingMeeting(meeting)
    setEditOpen(true)
  }

  const handleViewMeeting = (meeting: MeetingNote) => {
    setViewingMeeting(meeting)
    setViewOpen(true)
  }

  return (
    <div className="container py-10">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Meeting Notes</h1>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <PlusCircle className="mr-2 h-4 w-4" />
              Add Meeting Note
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Add New Meeting Note</DialogTitle>
              <DialogDescription>Record details and action items from your meeting.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="title">Meeting Title</Label>
                <Input
                  id="title"
                  value={newMeeting.title}
                  onChange={(e) => setNewMeeting({ ...newMeeting, title: e.target.value })}
                  placeholder="Meeting title"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="date">Meeting Date</Label>
                <Input
                  id="date"
                  type="date"
                  value={newMeeting.date}
                  onChange={(e) => setNewMeeting({ ...newMeeting, date: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="attendees">Attendees</Label>
                <Input
                  id="attendees"
                  value={newMeeting.attendees}
                  onChange={(e) => setNewMeeting({ ...newMeeting, attendees: e.target.value })}
                  placeholder="Names of attendees (comma separated)"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="notes">Meeting Notes</Label>
                <Textarea
                  id="notes"
                  value={newMeeting.notes}
                  onChange={(e) => setNewMeeting({ ...newMeeting, notes: e.target.value })}
                  placeholder="Key points discussed"
                  rows={4}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="actionItems">Action Items</Label>
                <Textarea
                  id="actionItems"
                  value={newMeeting.actionItems}
                  onChange={(e) => setNewMeeting({ ...newMeeting, actionItems: e.target.value })}
                  placeholder="Tasks to be completed (one per line)"
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddMeeting}>Save Meeting Note</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {meetings.length === 0 ? (
        <div className="text-center py-12">
          <h3 className="text-lg font-medium text-muted-foreground">No meeting notes yet</h3>
          <p className="text-muted-foreground mt-1">Add a new meeting note to get started</p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {meetings.map((meeting) => (
            <Card key={meeting.id} className="overflow-hidden">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>{meeting.title}</CardTitle>
                  <div className="flex space-x-1">
                    <Button variant="ghost" size="icon" onClick={() => handleEditMeeting(meeting)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="icon" onClick={() => handleDeleteMeeting(meeting.id)}>
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                  </div>
                </div>
                <CardDescription className="flex items-center gap-4">
                  <span className="flex items-center">
                    <Calendar className="h-3 w-3 mr-1" />
                    {new Date(meeting.date).toLocaleDateString()}
                  </span>
                  {meeting.attendees && (
                    <span className="flex items-center">
                      <Users className="h-3 w-3 mr-1" />
                      {meeting.attendees.split(",").length} attendees
                    </span>
                  )}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {meeting.notes && (
                  <div>
                    <h4 className="text-sm font-medium mb-1">Notes</h4>
                    <p className="text-sm text-muted-foreground whitespace-pre-line line-clamp-3">{meeting.notes}</p>
                  </div>
                )}
                {meeting.actionItems && (
                  <div>
                    <h4 className="text-sm font-medium mb-1">Action Items</h4>
                    <ul className="text-sm text-muted-foreground list-disc pl-5 space-y-1">
                      {meeting.actionItems
                        .split("\n")
                        .filter(Boolean)
                        .slice(0, 2)
                        .map((item, index) => (
                          <li key={index}>{item}</li>
                        ))}
                      {meeting.actionItems.split("\n").filter(Boolean).length > 2 && (
                        <li className="text-sm text-muted-foreground">
                          +{meeting.actionItems.split("\n").filter(Boolean).length - 2} more items
                        </li>
                      )}
                    </ul>
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button variant="outline" size="sm" onClick={() => handleViewMeeting(meeting)}>
                  View Full Notes
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}

      {/* Edit Meeting Dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Edit Meeting Note</DialogTitle>
            <DialogDescription>Update the details of your meeting note.</DialogDescription>
          </DialogHeader>
          {editingMeeting && (
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="edit-title">Meeting Title</Label>
                <Input
                  id="edit-title"
                  value={editingMeeting.title}
                  onChange={(e) => setEditingMeeting({ ...editingMeeting, title: e.target.value })}
                  placeholder="Meeting title"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-date">Meeting Date</Label>
                <Input
                  id="edit-date"
                  type="date"
                  value={editingMeeting.date}
                  onChange={(e) => setEditingMeeting({ ...editingMeeting, date: e.target.value })}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-attendees">Attendees</Label>
                <Input
                  id="edit-attendees"
                  value={editingMeeting.attendees}
                  onChange={(e) => setEditingMeeting({ ...editingMeeting, attendees: e.target.value })}
                  placeholder="Names of attendees (comma separated)"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-notes">Meeting Notes</Label>
                <Textarea
                  id="edit-notes"
                  value={editingMeeting.notes}
                  onChange={(e) => setEditingMeeting({ ...editingMeeting, notes: e.target.value })}
                  placeholder="Key points discussed"
                  rows={4}
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="edit-actionItems">Action Items</Label>
                <Textarea
                  id="edit-actionItems"
                  value={editingMeeting.actionItems}
                  onChange={(e) => setEditingMeeting({ ...editingMeeting, actionItems: e.target.value })}
                  placeholder="Tasks to be completed (one per line)"
                  rows={3}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateMeeting}>Update Meeting Note</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Meeting Dialog */}
      <Dialog open={viewOpen} onOpenChange={setViewOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>{viewingMeeting?.title}</DialogTitle>
            <DialogDescription>
              {viewingMeeting && (
                <div className="flex items-center gap-4 mt-1">
                  <span className="flex items-center">
                    <Calendar className="h-3 w-3 mr-1" />
                    {new Date(viewingMeeting.date).toLocaleDateString()}
                  </span>
                  {viewingMeeting.attendees && (
                    <span className="flex items-center">
                      <Users className="h-3 w-3 mr-1" />
                      Attendees: {viewingMeeting.attendees}
                    </span>
                  )}
                </div>
              )}
            </DialogDescription>
          </DialogHeader>
          {viewingMeeting && (
            <div className="grid gap-6 py-4">
              {viewingMeeting.notes && (
                <div>
                  <h3 className="text-lg font-medium mb-2">Notes</h3>
                  <div className="bg-muted p-4 rounded-md whitespace-pre-line">{viewingMeeting.notes}</div>
                </div>
              )}
              {viewingMeeting.actionItems && (
                <div>
                  <h3 className="text-lg font-medium mb-2">Action Items</h3>
                  <div className="bg-muted p-4 rounded-md">
                    <ul className="list-disc pl-5 space-y-2">
                      {viewingMeeting.actionItems
                        .split("\n")
                        .filter(Boolean)
                        .map((item, index) => (
                          <li key={index}>{item}</li>
                        ))}
                    </ul>
                  </div>
                </div>
              )}
              <div className="text-sm text-muted-foreground">
                Created on {new Date(viewingMeeting.createdAt).toLocaleString()}
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setViewOpen(false)}>
              Close
            </Button>
            <Button
              onClick={() => {
                setViewOpen(false)
                if (viewingMeeting) handleEditMeeting(viewingMeeting)
              }}
            >
              Edit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

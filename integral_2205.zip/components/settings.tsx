"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { useTheme } from "next-themes"

export default function Settings() {
  const [profile, setProfile] = useState({
    name: "John Doe",
    email: "john.doe@example.com",
    theme: "system",
    language: "en",
  })
  const { toast } = useToast()
  const { setTheme } = useTheme()

  useEffect(() => {
    // Load settings from local storage
    const storedSettings = localStorage.getItem("integral_settings")
    if (storedSettings) {
      try {
        setProfile(JSON.parse(storedSettings))
      } catch (error) {
        console.error("Failed to parse stored settings:", error)
      }
    }
  }, [])

  const handleSaveSettings = () => {
    localStorage.setItem("integral_settings", JSON.stringify(profile))
    setTheme(profile.theme)

    toast({
      title: "Settings Saved",
      description: "Your settings have been saved successfully",
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Settings</CardTitle>
      </CardHeader>
      <CardContent className="grid gap-6">
        <div className="grid gap-2">
          <Label htmlFor="name">Name</Label>
          <Input id="name" value={profile.name} onChange={(e) => setProfile({ ...profile, name: e.target.value })} />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            value={profile.email}
            onChange={(e) => setProfile({ ...profile, email: e.target.value })}
          />
        </div>
        <div className="grid gap-2">
          <Label htmlFor="theme">Theme</Label>
          <Select value={profile.theme} onValueChange={(value: any) => setProfile({ ...profile, theme: value })}>
            <SelectTrigger id="theme">
              <SelectValue placeholder="Select theme" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="light">Light</SelectItem>
              <SelectItem value="dark">Dark</SelectItem>
              <SelectItem value="system">System</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="grid gap-2">
          <Label htmlFor="language">Language</Label>
          <Select value={profile.language} onValueChange={(value: any) => setProfile({ ...profile, language: value })}>
            <SelectTrigger id="language">
              <SelectValue placeholder="Select language" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="en">English</SelectItem>
              <SelectItem value="es">Spanish</SelectItem>
              <SelectItem value="fr">French</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button onClick={handleSaveSettings}>Save Settings</Button>
      </CardContent>
    </Card>
  )
}

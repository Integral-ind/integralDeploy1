import { cn } from "@/lib/utils"

interface LogoProps {
  className?: string
  size?: "sm" | "md" | "lg" | "xl"
  variant?: "default" | "white" | "dark"
}

export function Logo({ className, size = "md", variant = "default" }: LogoProps) {
  // Define size dimensions
  const sizes = {
    sm: { width: 120, height: 40 },
    md: { width: 160, height: 53 },
    lg: { width: 200, height: 67 },
    xl: { width: 240, height: 80 },
  }

  // Get dimensions based on size prop
  const { width, height } = sizes[size]

  return (
    <div className={cn("relative flex items-center", className)}>
      <div
        className={cn(
          "relative",
          variant === "white" && "filter brightness-0 invert",
          variant === "dark" && "filter brightness-0",
        )}
        style={{ width: `${width}px`, height: `${height}px` }}
      >
        {/* For the landing page and larger displays */}
        <div className="flex items-center h-full">
          <div className="relative w-full h-full">
            {/* Infinity symbol with gradient */}
            <div className="absolute left-0 top-0 w-[40%] h-full">
              <div className="w-full h-full relative">
                <div className="absolute w-full h-full rounded-full border-2 border-transparent bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 opacity-80"></div>
              </div>
            </div>

            {/* Text part */}
            <div className="absolute right-0 bottom-0 w-[70%] h-full flex items-center">
              <span
                className={cn(
                  "text-2xl md:text-3xl font-light",
                  variant === "default" && "text-white",
                  variant === "white" && "text-white",
                  variant === "dark" && "text-black",
                )}
              >
                integral
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

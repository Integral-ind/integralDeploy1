"use client"

import type React from "react"

import { useState, useEffect, useMemo } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent } from "@/components/ui/tabs"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Code,
  CheckSquare,
  Home,
  Star,
  Briefcase,
  User,
  Search,
  Plus,
  Save,
  Trash2,
  Pin,
  FileText,
  Menu,
  X,
  Tag,
  Loader2,
} from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { cn } from "@/lib/utils"
import { useMobile } from "@/hooks/use-mobile"
import dynamic from "next/dynamic"

// Dynamically import our custom rich text editor component with SSR disabled
const RichTextEditor = dynamic(() => import("@/components/rich-text-editor"), {
  ssr: false,
  loading: () => (
    <div className="h-64 flex items-center justify-center">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>
  ),
})

// Types
type NoteTag = "Work" | "Personal" | "Ideas" | "Tasks" | string

interface Note {
  id: string
  title: string
  content: string
  preview: string
  createdAt: Date
  updatedAt: Date
  tags: NoteTag[]
  isFavorite: boolean
  isPinned: boolean
  category?: string
}

interface NoteFormData {
  title: string
  content: string
  tags: NoteTag[]
  category?: string
}

type CategoryFilter = "All" | "Favorites" | "Work" | "Personal" | "Ideas" | "Tasks"

// Preset tags
const presetTags: NoteTag[] = ["Work", "Personal", "Ideas", "Tasks"]

// Mock data for initial notes
const initialNotes: Note[] = [
  {
    id: "note1",
    title: "Welcome to Integral Notes",
    content:
      '<h2>Getting Started</h2><p>Welcome to your new productivity system! Here are some tips to get started:</p><ul><li>Create notes by clicking the "New Note" button</li><li>Organize with tags like Work or Personal</li><li>Star important notes to find them quickly</li><li>Use the rich text editor to format your content</li></ul>',
    preview: "Welcome to your new productivity system! Here are some tips to get started...",
    createdAt: new Date("2025-03-10T12:00:00Z"),
    updatedAt: new Date("2025-03-10T12:00:00Z"),
    tags: ["Ideas"],
    isFavorite: true,
    isPinned: true,
  },
  {
    id: "note2",
    title: "Project Ideas",
    content:
      "<h3>Ideas for Q2 2025</h3><p>Here are some potential projects we could explore:</p><ol><li>Mobile app expansion</li><li>Integration with calendar systems</li><li>Advanced analytics dashboard</li></ol><p>Need to discuss prioritization in next planning meeting.</p>",
    preview:
      "Here are some potential projects we could explore: Mobile app expansion, Integration with calendar systems...",
    createdAt: new Date("2025-03-12T14:30:00Z"),
    updatedAt: new Date("2025-03-15T09:15:00Z"),
    tags: ["Work", "Ideas"],
    isFavorite: false,
    isPinned: false,
  },
  {
    id: "note3",
    title: "Shopping List",
    content:
      "<p>Things to buy:</p><ul><li>Groceries<ul><li>Milk</li><li>Eggs</li><li>Bread</li><li>Vegetables</li></ul></li><li>New notebook</li><li>Gifts for anniversary</li></ul>",
    preview: "Things to buy: Groceries (Milk, Eggs, Bread, Vegetables), New notebook, Gifts for anniversary",
    createdAt: new Date("2025-03-20T18:45:00Z"),
    updatedAt: new Date("2025-03-20T18:45:00Z"),
    tags: ["Personal", "Tasks"],
    isFavorite: true,
    isPinned: false,
  },
]

// Note List Item Component
const NoteListItem = ({
  note,
  isSelected,
  onSelect,
  onToggleFavorite,
  onTogglePinned,
  onDeleteNote,
}: {
  note: Note
  isSelected: boolean
  onSelect: (note: Note) => void
  onToggleFavorite: (id: string, isFavorite: boolean) => void
  onTogglePinned: (id: string, isPinned: boolean) => void
  onDeleteNote: (note: Note) => void
}) => {
  // Format date
  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
  }

  return (
    <div
      className={cn(
        "group relative p-3 border-b border-border cursor-pointer transition-colors duration-200 hover:bg-accent/50",
        isSelected ? "bg-accent" : "bg-card",
      )}
      onClick={() => onSelect(note)}
    >
      {note.isPinned && (
        <div className="absolute top-2 right-10 text-primary">
          <Pin size={16} className="fill-primary" />
        </div>
      )}

      <div className="flex justify-between items-start">
        <div className="max-w-[85%]">
          <h3 className="font-medium truncate">{note.title || "Untitled Note"}</h3>
          <p className="text-xs text-muted-foreground mt-1">{formatDate(note.updatedAt)}</p>

          <div className="flex flex-wrap gap-1 mt-2">
            {note.tags.map((tag, index) => (
              <Badge key={index} variant="outline" className="text-xs bg-primary/10 text-primary">
                {tag}
              </Badge>
            ))}
          </div>

          <p className="mt-2 text-sm text-muted-foreground line-clamp-2">{note.preview}</p>
        </div>

        <div className="flex flex-col space-y-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={(e) => {
              e.stopPropagation()
              onToggleFavorite(note.id, !note.isFavorite)
            }}
            aria-label={note.isFavorite ? "Remove from favorites" : "Add to favorites"}
          >
            <Star size={16} className={note.isFavorite ? "fill-yellow-400 text-yellow-400" : ""} />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={(e) => {
              e.stopPropagation()
              onTogglePinned(note.id, !note.isPinned)
            }}
            aria-label={note.isPinned ? "Unpin note" : "Pin note"}
          >
            <Pin size={16} className={note.isPinned ? "fill-primary text-primary" : ""} />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 text-destructive"
            onClick={(e) => {
              e.stopPropagation()
              onDeleteNote(note)
            }}
            aria-label="Delete note"
          >
            <Trash2 size={16} />
          </Button>
        </div>
      </div>
    </div>
  )
}

// Note Sidebar Component
const NoteSidebar = ({
  notes,
  selectedNote,
  onSelectNote,
  onCreateNote,
  onToggleFavorite,
  onTogglePinned,
  onDeleteNote,
}: {
  notes: Note[]
  selectedNote: Note | null
  onSelectNote: (note: Note) => void
  onCreateNote: () => void
  onToggleFavorite: (id: string, isFavorite: boolean) => void
  onTogglePinned: (id: string, isPinned: boolean) => void
  onDeleteNote: (note: Note) => void
}) => {
  const [searchQuery, setSearchQuery] = useState("")
  const [activeCategory, setActiveCategory] = useState<CategoryFilter>("All")

  const filteredNotes = useMemo(() => {
    return notes
      .filter((note) => {
        // First filter by search query
        const matchesSearch =
          searchQuery === "" ||
          note.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          note.content.toLowerCase().includes(searchQuery.toLowerCase())

        // Then filter by category
        const matchesCategory =
          activeCategory === "All" ||
          (activeCategory === "Favorites" && note.isFavorite) ||
          note.tags.includes(activeCategory as NoteTag)

        return matchesSearch && matchesCategory
      })
      .sort((a, b) => {
        // Sort by pinned first, then by updated date
        if (a.isPinned && !b.isPinned) return -1
        if (!a.isPinned && b.isPinned) return 1
        return b.updatedAt.getTime() - a.updatedAt.getTime()
      })
  }, [notes, searchQuery, activeCategory])

  const categories: { id: CategoryFilter; label: string; icon: React.ReactNode }[] = [
    { id: "All", label: "All Notes", icon: <Home size={18} className="text-muted-foreground" /> },
    { id: "Favorites", label: "Favorites", icon: <Star size={18} className="text-yellow-500" /> },
    { id: "Work", label: "Work", icon: <Briefcase size={18} className="text-blue-500" /> },
    { id: "Personal", label: "Personal", icon: <User size={18} className="text-green-500" /> },
    { id: "Ideas", label: "Ideas", icon: <FileText size={18} className="text-purple-500" /> },
    { id: "Tasks", label: "Tasks", icon: <CheckSquare size={18} className="text-orange-500" /> },
  ]

  return (
    <aside className="bg-card h-full flex flex-col border-r border-border w-80">
      <div className="p-4 border-b border-border">
        <h2 className="text-xl font-semibold">Notes</h2>

        <div className="mt-4 flex">
          <Button onClick={onCreateNote} className="w-full">
            <Plus size={18} className="mr-2" />
            New Note
          </Button>
        </div>

        <div className="mt-4 relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search notes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      <nav className="p-3 border-b border-border">
        <ul>
          {categories.map((category) => (
            <li key={category.id}>
              <Button
                variant={activeCategory === category.id ? "secondary" : "ghost"}
                className="w-full justify-start"
                onClick={() => setActiveCategory(category.id)}
              >
                <span className="mr-3">{category.icon}</span>
                {category.label}
                <span className="ml-auto bg-muted text-muted-foreground text-xs px-2 py-0.5 rounded-full">
                  {category.id === "All"
                    ? notes.length
                    : category.id === "Favorites"
                      ? notes.filter((note) => note.isFavorite).length
                      : notes.filter((note) => note.tags.includes(category.id)).length}
                </span>
              </Button>
            </li>
          ))}
        </ul>
      </nav>

      <div className="flex-1 overflow-y-auto">
        {filteredNotes.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-40 text-muted-foreground">
            <p>No notes found</p>
            {searchQuery && (
              <Button variant="link" onClick={() => setSearchQuery("")}>
                Clear search
              </Button>
            )}
          </div>
        ) : (
          filteredNotes.map((note) => (
            <NoteListItem
              key={note.id}
              note={note}
              isSelected={selectedNote?.id === note.id}
              onSelect={onSelectNote}
              onToggleFavorite={onToggleFavorite}
              onTogglePinned={onTogglePinned}
              onDeleteNote={onDeleteNote}
            />
          ))
        )}
      </div>
    </aside>
  )
}

// Note Editor Component
const NoteEditor = ({
  note,
  onSave,
  onToggleFavorite,
  isNew = false,
}: {
  note: Note | null
  onSave: (id: string | null, data: NoteFormData) => void
  onToggleFavorite: (id: string, isFavorite: boolean) => void
  isNew?: boolean
}) => {
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [tags, setTags] = useState<NoteTag[]>([])
  const [newTag, setNewTag] = useState("")
  const [isSaving, setIsSaving] = useState(false)
  const [autoSaveTimer, setAutoSaveTimer] = useState<NodeJS.Timeout | null>(null)
  const [isModified, setIsModified] = useState(false)
  const [editorMode, setEditorMode] = useState<"rich" | "markdown">("rich")
  const [markdownContent, setMarkdownContent] = useState("")
  const { toast } = useToast()

  // Initialize form when note changes
  useEffect(() => {
    if (note) {
      setTitle(note.title)
      setContent(note.content)
      setTags(note.tags)
      setIsModified(false)
      // Convert HTML to markdown-like plain text for the markdown view
      setMarkdownContent(convertHtmlToPlainText(note.content))
    } else if (isNew) {
      setTitle("")
      setContent("")
      setMarkdownContent("")
      setTags([])
      setIsModified(false)
    }
  }, [note, isNew])

  // Auto-save with debounce
  useEffect(() => {
    if (isModified && !isNew && note) {
      if (autoSaveTimer) {
        clearTimeout(autoSaveTimer)
      }

      const timer = setTimeout(() => {
        handleSave()
      }, 3000) // 3 seconds debounce

      setAutoSaveTimer(timer)
    }

    return () => {
      if (autoSaveTimer) {
        clearTimeout(autoSaveTimer)
      }
    }
  }, [title, content, markdownContent, tags, isModified, isNew, note])

  // Simple HTML to plain text converter
  const convertHtmlToPlainText = (html: string): string => {
    // Create a temporary div to hold the HTML
    if (typeof document !== "undefined") {
      const tempDiv = document.createElement("div")
      tempDiv.innerHTML = html

      // Replace some common HTML elements with markdown-like equivalents
      const headings = tempDiv.querySelectorAll("h1, h2, h3, h4, h5, h6")
      headings.forEach((heading) => {
        const level = heading.tagName.charAt(1)
        const text = heading.textContent
        const hashes = "#".repeat(Number.parseInt(level))
        heading.textContent = `${hashes} ${text}`
      })

      // Replace lists
      const lis = tempDiv.querySelectorAll("li")
      lis.forEach((li) => {
        const isOrderedList = li.parentElement?.tagName === "OL"
        li.textContent = `${isOrderedList ? "1. " : "- "}${li.textContent}`
      })

      // Get the plain text
      return tempDiv.textContent || ""
    }
    return html.replace(/<[^>]*>/g, "")
  }

  // Convert plain text to HTML for saving
  const convertPlainTextToHtml = (text: string): string => {
    let html = text

    // Convert line breaks to paragraphs
    html = "<p>" + html.replace(/\n\n/g, "</p><p>") + "</p>"

    // Convert single line breaks within paragraphs to <br>
    html = html.replace(/<p>(.*?)\n(.*?)<\/p>/g, "<p>$1<br>$2</p>")

    // This is very basic - a more sophisticated converter would be needed for production
    return html
  }

  const handleSave = () => {
    if (!title.trim() && !content.trim() && !markdownContent.trim()) return

    setIsSaving(true)

    let finalContent = content
    // If in markdown mode, convert the markdown content to HTML
    if (editorMode === "markdown") {
      finalContent = convertPlainTextToHtml(markdownContent)
    }

    const noteData: NoteFormData = {
      title: title.trim() || "Untitled Note",
      content: finalContent,
      tags,
    }

    onSave(note?.id || null, noteData)

    setIsSaving(false)
    setIsModified(false)

    toast({
      title: note ? "Note updated" : "Note created",
      description: note ? "Your changes have been saved" : "Your new note has been created",
    })
  }

  const handleContentChange = (value: string) => {
    setContent(value)
    setIsModified(true)
  }

  const handleMarkdownChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMarkdownContent(e.target.value)
    setIsModified(true)
  }

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setTitle(e.target.value)
    setIsModified(true)
  }

  const handleAddTag = () => {
    if (newTag.trim() && !tags.includes(newTag.trim() as NoteTag)) {
      setTags([...tags, newTag.trim() as NoteTag])
      setNewTag("")
      setIsModified(true)
    }
  }

  const handleRemoveTag = (tagToRemove: NoteTag) => {
    setTags(tags.filter((tag) => tag !== tagToRemove))
    setIsModified(true)
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      e.preventDefault()
      handleAddTag()
    }
  }

  // If no note is selected and not creating a new one
  if (!note && !isNew) {
    return (
      <div className="flex-1 flex items-center justify-center bg-muted/50 text-muted-foreground">
        <p>Select a note or create a new one</p>
      </div>
    )
  }

  return (
    <div className="flex-1 flex flex-col bg-card h-full overflow-hidden">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <Input
            type="text"
            value={title}
            onChange={handleTitleChange}
            placeholder="Note Title"
            className="text-xl font-medium border-none bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 px-0"
          />

          <div className="flex items-center space-x-2">
            {note && (
              <Button
                variant="ghost"
                size="icon"
                onClick={() => onToggleFavorite(note.id, !note.isFavorite)}
                className={note.isFavorite ? "text-yellow-500" : "text-muted-foreground"}
                aria-label={note.isFavorite ? "Remove from favorites" : "Add to favorites"}
              >
                <Star className={note.isFavorite ? "fill-yellow-400" : ""} size={20} />
              </Button>
            )}

            <Button
              variant="outline"
              size="sm"
              onClick={() => setEditorMode(editorMode === "rich" ? "markdown" : "rich")}
              className={editorMode === "markdown" ? "bg-muted" : ""}
            >
              {editorMode === "markdown" ? (
                <>
                  <FileText className="mr-2 h-4 w-4" />
                  Rich Text
                </>
              ) : (
                <>
                  <Code className="mr-2 h-4 w-4" />
                  Markdown
                </>
              )}
            </Button>

            <Button onClick={handleSave} disabled={isSaving || (!isModified && !isNew)} className="flex items-center">
              {isSaving ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Save
                </>
              )}
            </Button>
          </div>
        </div>

        <div className="mt-4">
          <div className="flex items-center space-x-2 mb-2">
            <Tag size={16} className="text-muted-foreground" />
            <span className="text-sm text-muted-foreground">Tags:</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {tags.map((tag, index) => (
              <Badge key={index} variant="outline" className="bg-primary/10 text-primary">
                {tag}
                <Button variant="ghost" size="icon" className="h-4 w-4 ml-1 p-0" onClick={() => handleRemoveTag(tag)}>
                  <X size={12} />
                </Button>
              </Badge>
            ))}

            <div className="flex items-center">
              <Input
                type="text"
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Add tag..."
                className="text-sm border-b border-dashed border-muted-foreground focus-visible:ring-0 focus-visible:ring-offset-0 border-0 bg-transparent h-7 px-2 w-24"
              />
            </div>
          </div>

          <div className="mt-2 flex flex-wrap gap-1">
            {presetTags
              .filter((tag) => !tags.includes(tag))
              .map((tag) => (
                <Button
                  key={tag}
                  variant="outline"
                  size="sm"
                  className="h-6 text-xs"
                  onClick={() => {
                    setTags([...tags, tag])
                    setIsModified(true)
                  }}
                >
                  + {tag}
                </Button>
              ))}
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-auto p-4">
        <Tabs value={editorMode} onValueChange={(value) => setEditorMode(value as "rich" | "markdown")}>
          <TabsContent value="rich" className="h-full mt-0">
            <RichTextEditor
              value={content}
              onChange={handleContentChange}
              placeholder="Start writing your note here..."
              className="h-full"
            />
          </TabsContent>
          <TabsContent value="markdown" className="h-full mt-0">
            <Textarea
              value={markdownContent}
              onChange={handleMarkdownChange}
              placeholder="Start writing your note here in markdown mode..."
              className="w-full h-full p-4 font-mono resize-none"
            />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

// Main Notes Component
export default function NotesV2() {
  const [notes, setNotes] = useState<Note[]>([])
  const [selectedNote, setSelectedNote] = useState<Note | null>(null)
  const [isCreatingNew, setIsCreatingNew] = useState(false)
  const [noteToDelete, setNoteToDelete] = useState<Note | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const { isMobile } = useMobile()
  const { toast } = useToast()

  // Load notes from localStorage on initial load
  useEffect(() => {
    const storedNotes = localStorage.getItem("integral_notes")
    if (storedNotes) {
      try {
        // Parse notes and convert string dates back to Date objects
        const parsedNotes = JSON.parse(storedNotes).map((note: any) => ({
          ...note,
          createdAt: new Date(note.createdAt),
          updatedAt: new Date(note.updatedAt),
        }))
        setNotes(parsedNotes)

        // Set first note as selected if available
        if (parsedNotes.length > 0 && !selectedNote) {
          setSelectedNote(parsedNotes[0])
        }
      } catch (error) {
        console.error("Failed to parse stored notes:", error)
        // If parsing fails, initialize with default notes
        setNotes(initialNotes)
      }
    } else {
      // If no stored notes, initialize with default notes
      setNotes(initialNotes)
      if (initialNotes.length > 0) {
        setSelectedNote(initialNotes[0])
      }
    }
  }, [])

  // Save notes to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("integral_notes", JSON.stringify(notes))
  }, [notes])

  // Check if on mobile and set sidebar accordingly
  useEffect(() => {
    if (isMobile) {
      setSidebarOpen(false)
    } else {
      setSidebarOpen(true)
    }
  }, [isMobile])

  const handleSelectNote = (note: Note) => {
    setSelectedNote(note)
    setIsCreatingNew(false)
    if (isMobile) {
      setSidebarOpen(false)
    }
  }

  const handleCreateNote = () => {
    setSelectedNote(null)
    setIsCreatingNew(true)
    if (isMobile) {
      setSidebarOpen(false)
    }
  }

  const handleSaveNote = (id: string | null, data: NoteFormData) => {
    if (id) {
      // Update existing note
      const updatedNotes = notes.map((note) => {
        if (note.id === id) {
          const updatedNote = {
            ...note,
            ...data,
            updatedAt: new Date(),
            preview: data.content.replace(/<[^>]*>/g, "").substring(0, 100) + "...",
          }
          setSelectedNote(updatedNote)
          return updatedNote
        }
        return note
      })
      setNotes(updatedNotes)
    } else {
      // Create new note
      const newNote: Note = {
        id: `note${Date.now()}`,
        ...data,
        preview: data.content.replace(/<[^>]*>/g, "").substring(0, 100) + "...",
        createdAt: new Date(),
        updatedAt: new Date(),
        isFavorite: false,
        isPinned: false,
      }
      setNotes([newNote, ...notes])
      setSelectedNote(newNote)
      setIsCreatingNew(false)
    }
  }

  const handleToggleFavorite = (id: string, isFavorite: boolean) => {
    const updatedNotes = notes.map((note) => {
      if (note.id === id) {
        return {
          ...note,
          isFavorite,
          updatedAt: new Date(),
        }
      }
      return note
    })
    setNotes(updatedNotes)

    // Update selected note if it's the one being modified
    if (selectedNote?.id === id) {
      setSelectedNote({ ...selectedNote, isFavorite })
    }

    toast({
      title: isFavorite ? "Added to favorites" : "Removed from favorites",
      description: isFavorite ? "Note marked as favorite" : "Note removed from favorites",
    })
  }

  const handleTogglePinned = (id: string, isPinned: boolean) => {
    const updatedNotes = notes.map((note) => {
      if (note.id === id) {
        return {
          ...note,
          isPinned,
          updatedAt: new Date(),
        }
      }
      return note
    })
    setNotes(updatedNotes)

    // Update selected note if it's the one being modified
    if (selectedNote?.id === id) {
      setSelectedNote({ ...selectedNote, isPinned })
    }

    toast({
      title: isPinned ? "Note pinned" : "Note unpinned",
      description: isPinned ? "Note has been pinned to the top" : "Note has been unpinned",
    })
  }

  const handleDeleteNote = () => {
    if (noteToDelete) {
      const updatedNotes = notes.filter((note) => note.id !== noteToDelete.id)
      setNotes(updatedNotes)

      // If the deleted note was selected, clear selection or select another note
      if (selectedNote?.id === noteToDelete.id) {
        setSelectedNote(updatedNotes.length > 0 ? updatedNotes[0] : null)
      }

      setNoteToDelete(null)

      toast({
        title: "Note deleted",
        description: `"${noteToDelete.title}" has been deleted`,
      })
    }
  }

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen)
  }

  return (
    <Card className="h-[calc(100vh-140px)]">
      <CardContent className="p-0 h-full flex flex-col md:flex-row">
        {/* Mobile menu toggle */}
        <div className="md:hidden p-2 border-b border-border">
          <Button variant="outline" size="sm" onClick={toggleSidebar} className="flex items-center">
            <Menu size={18} className="mr-2" />
            {sidebarOpen ? "Hide Notes" : "Show Notes"}
          </Button>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Responsive sidebar */}
          <div
            className={cn(
              sidebarOpen ? "block" : "hidden",
              "md:block",
              isMobile ? "absolute inset-0 z-10 bg-background" : "relative",
              "md:relative",
            )}
          >
            <NoteSidebar
              notes={notes}
              selectedNote={selectedNote}
              onSelectNote={handleSelectNote}
              onCreateNote={handleCreateNote}
              onToggleFavorite={handleToggleFavorite}
              onTogglePinned={handleTogglePinned}
              onDeleteNote={setNoteToDelete}
            />
          </div>

          {/* Note editor */}
          <div className={cn(!sidebarOpen || !isMobile ? "block" : "hidden", "md:block flex-1")}>
            <NoteEditor
              note={selectedNote}
              onSave={handleSaveNote}
              onToggleFavorite={handleToggleFavorite}
              isNew={isCreatingNew}
            />
          </div>
        </div>
      </CardContent>

      {/* Delete confirmation dialog */}
      <AlertDialog open={!!noteToDelete} onOpenChange={(open) => !open && setNoteToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the note "{noteToDelete?.title || "Untitled Note"}". This action cannot be
              undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteNote} variant="destructive">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  )
}

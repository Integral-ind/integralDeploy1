"use client"

import { useEffect, useState, useRef } from "react"
import { Loader2 } from "lucide-react"

// Define props interface
interface RichTextEditorProps {
  value: string
  onChange: (value: string) => void
  placeholder?: string
  className?: string
}

// Create a component that only imports and renders ReactQuill on the client side
export default function RichTextEditor({ value, onChange, placeholder, className }: RichTextEditorProps) {
  const [mounted, setMounted] = useState(false)
  const editorRef = useRef<HTMLDivElement>(null)
  const [quillInstance, setQuillInstance] = useState<any>(null)
  const valueRef = useRef(value)

  // Update the ref when value changes
  useEffect(() => {
    valueRef.current = value
  }, [value])

  // Initialize Quill with vanilla JS to avoid React's findDOMNode
  useEffect(() => {
    if (typeof window === "undefined") return

    // Load Quill and initialize it
    const loadQuill = async () => {
      try {
        // Import both Quill and React-Quill styles
        await import("react-quill/dist/quill.snow.css")

        // Import Quill directly (not React-Quill)
        const Quill = (await import("quill")).default

        if (!editorRef.current || quillInstance) return

        // Create toolbar options
        const toolbarOptions = [
          [{ header: [1, 2, 3, false] }],
          ["bold", "italic", "underline"],
          [{ list: "ordered" }, { list: "bullet" }],
          [{ indent: "-1" }, { indent: "+1" }],
          [{ align: [] }],
          ["clean"],
        ]

        // Initialize Quill
        const quill = new Quill(editorRef.current, {
          modules: {
            toolbar: toolbarOptions,
          },
          placeholder: placeholder || "Start writing...",
          theme: "snow",
        })

        // Set initial content
        quill.clipboard.dangerouslyPasteHTML(valueRef.current)

        // Handle text change
        quill.on("text-change", () => {
          const html = editorRef.current?.querySelector(".ql-editor")?.innerHTML || ""
          if (html !== valueRef.current) {
            onChange(html)
          }
        })

        setQuillInstance(quill)
        setMounted(true)
      } catch (error) {
        console.error("Failed to load Quill:", error)
      }
    }

    loadQuill()

    // Cleanup
    return () => {
      if (quillInstance) {
        // Clean up Quill instance if needed
      }
    }
  }, [])

  // Update Quill content when value prop changes (if different from current content)
  useEffect(() => {
    if (quillInstance && mounted) {
      const currentContent = editorRef.current?.querySelector(".ql-editor")?.innerHTML || ""
      if (value !== currentContent) {
        quillInstance.clipboard.dangerouslyPasteHTML(value)
      }
    }
  }, [value, quillInstance, mounted])

  // Show loading state while the editor is being loaded
  if (!mounted) {
    return (
      <div className="h-64 flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  // Render the editor container
  return (
    <div className={className}>
      <div ref={editorRef} className="quill-editor" />
    </div>
  )
}

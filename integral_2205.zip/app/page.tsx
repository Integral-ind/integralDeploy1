"use client"

import { useEffect, useState, useRef } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { useAuth } from "@/lib/auth-context"
import { motion, useScroll, useTransform, AnimatePresence } from "framer-motion"
import { Canvas } from "@react-three/fiber"
import { Float, Environment, PresentationControls } from "@react-three/drei"
import { ChevronRight, ArrowRight, Check, Menu, X, Github, Twitter, Linkedin, Instagram } from "lucide-react"

// Floating 3D Elements
function FloatingSpheres() {
  const [mounted, setMounted] = useState(true) // Changed from false to true

  // Use a ref to track if the component has been mounted
  const hasRendered = useRef(false)

  useEffect(() => {
    // Only set mounted if it hasn't been rendered yet
    if (!hasRendered.current) {
      hasRendered.current = true
      setMounted(true)
    }
  }, [])

  // Remove the loading spinner and render the Canvas immediately
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      <Canvas
        camera={{ position: [0, 0, 5], fov: 45 }}
        dpr={[1, 2]}
        style={{ opacity: 1 }}
        frameloop="always" // Ensure animation runs immediately
        gl={{ alpha: true, antialias: true }} // Improve rendering quality
        performance={{ min: 0.5 }} // Optimize performance
      >
        <ambientLight intensity={0.5} />
        <directionalLight position={[10, 10, 5]} intensity={1} />
        <Environment preset="city" />

        <PresentationControls
          global
          rotation={[0.13, 0.1, 0]}
          polar={[-0.4, 0.2]}
          azimuth={[-1, 0.75]}
          config={{ mass: 2, tension: 400 }}
          snap={{ mass: 4, tension: 400 }}
        >
          <Float rotationIntensity={0.4}>
            <group>
              {/* Main sphere */}
              <mesh position={[0, 0, 0]}>
                <sphereGeometry args={[1.2, 32, 32]} />
                <meshStandardMaterial color="#4338ca" metalness={0.7} roughness={0.2} />
              </mesh>

              {/* Orbiting torus */}
              <mesh position={[0, 0, 0]} rotation={[Math.PI / 2, 0, 0]}>
                <torusGeometry args={[2, 0.2, 16, 100]} />
                <meshStandardMaterial color="#8b5cf6" metalness={0.7} roughness={0.2} />
              </mesh>

              {/* Small orbiting spheres */}
              <Float speed={5} rotationIntensity={2} floatIntensity={2}>
                <mesh position={[2, 0, 0]}>
                  <sphereGeometry args={[0.3, 32, 32]} />
                  <meshStandardMaterial color="#3b82f6" metalness={0.8} roughness={0.2} />
                </mesh>
              </Float>

              <Float speed={5} rotationIntensity={2} floatIntensity={2}>
                <mesh position={[-1.5, 1, 0]}>
                  <sphereGeometry args={[0.4, 32, 32]} />
                  <meshStandardMaterial color="#ec4899" metalness={0.8} roughness={0.2} />
                </mesh>
              </Float>

              <Float speed={5} rotationIntensity={2} floatIntensity={2}>
                <mesh position={[-1, -1.5, 0]}>
                  <sphereGeometry args={[0.2, 32, 32]} />
                  <meshStandardMaterial color="#06b6d4" metalness={0.8} roughness={0.2} />
                </mesh>
              </Float>
            </group>
          </Float>
        </PresentationControls>
      </Canvas>
    </div>
  )
}

// Animated Gradient Background
function AnimatedBackground() {
  return (
    <div className="fixed inset-0 z-[-1]">
      <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black" />
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent blur-2xl transform-gpu" />
        <div className="absolute bottom-0 right-0 w-full h-full bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-blue-900/20 via-transparent to-transparent blur-2xl transform-gpu" />
      </div>
      <div className="absolute inset-0 bg-[url('/grid.svg')] bg-center [mask-image:linear-gradient(180deg,white,rgba(255,255,255,0))]" />
    </div>
  )
}

export default function LandingPage() {
  const router = useRouter()
  const { user } = useAuth()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const { scrollYProgress } = useScroll()
  const heroRef = useRef(null)
  const featuresRef = useRef(null)
  const pricingRef = useRef(null)

  // Improve text visibility throughout the page by:
  // 1. Adding text shadows to important headings
  // 2. Increasing contrast with background elements
  // 3. Adding subtle backdrop effects behind text

  // For the hero section heading and subheading
  const heroTextY = useTransform(scrollYProgress, [0, 0.2], [0, -50])
  const heroOpacity = useTransform(scrollYProgress, [0, 0.2], [1, 0])

  useEffect(() => {
    // If user is already logged in, redirect to dashboard
    if (user) {
      router.push("/dashboard")
    }
  }, [user, router])

  return (
    <>
      <AnimatedBackground />

      {/* Header */}
      <header className="fixed w-full z-50 backdrop-blur-md bg-black/20 border-b border-white/5">
        <div className="container mx-auto px-6">
          <div className="flex justify-between items-center py-4 h-16">
            <div className="flex items-center gap-3">
              <div className="text-2xl font-light text-white">
                <span className="bg-gradient-to-r from-blue-400 to-violet-500 bg-clip-text text-transparent">
                  integral
                </span>
              </div>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex gap-8">
              {["Features", "Showcase", "Pricing", "Contact"].map((item) => (
                <a
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className="text-gray-300 hover:text-white font-medium text-sm relative after:absolute after:w-0 after:h-0.5 after:bottom-[-4px] after:left-0 after:bg-gradient-to-r after:from-blue-400 after:to-violet-500 after:transition-all hover:after:w-full"
                >
                  {item}
                </a>
              ))}
            </nav>

            {/* Mobile Menu Button */}
            <button className="md:hidden text-white" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>

            {/* CTA Buttons */}
            <div className="hidden md:flex gap-3">
              <Link
                href="/login"
                className="px-4 py-2 rounded-md text-sm font-medium border border-white/10 text-white hover:bg-white/5 transition-colors"
              >
                Login
              </Link>
              <Link
                href="/signup"
                className="px-4 py-2 rounded-md text-sm font-medium text-white bg-gradient-to-r from-blue-500 to-violet-500 hover:from-blue-600 hover:to-violet-600 transition-colors"
              >
                Sign Up
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed inset-0 z-40 bg-black/95 pt-20 px-6"
          >
            <div className="flex flex-col gap-6">
              {["Features", "Showcase", "Pricing", "Contact"].map((item) => (
                <a
                  key={item}
                  href={`#${item.toLowerCase()}`}
                  className="text-gray-300 hover:text-white font-medium text-lg py-2 border-b border-white/10"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item}
                </a>
              ))}
              <div className="flex flex-col gap-3 mt-4">
                <Link
                  href="/login"
                  className="px-4 py-3 rounded-md text-center font-medium border border-white/10 text-white hover:bg-white/5 transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Login
                </Link>
                <Link
                  href="/signup"
                  className="px-4 py-3 rounded-md text-center font-medium text-white bg-gradient-to-r from-blue-500 to-violet-500 hover:from-blue-600 hover:to-violet-600 transition-colors"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  Sign Up
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Hero Section */}
      <section ref={heroRef} className="relative min-h-screen flex items-center pt-20 overflow-hidden">
        <div className="container mx-auto px-6 relative z-10">
          <div className="flex flex-col items-center text-center max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center px-3 py-1.5 bg-white/5 backdrop-blur-md rounded-full mb-6 text-sm font-medium text-white border border-white/10"
            >
              <span className="bg-gradient-to-r from-blue-400 to-violet-500 bg-clip-text text-transparent">
                ✦ Next Generation Workspace
              </span>
            </motion.div>

            {/* Update the hero section text styling */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              style={{ y: heroTextY }}
              className="text-5xl md:text-7xl font-bold mb-6 leading-tight text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]"
            >
              Transform Your <br />
              <span className="bg-gradient-to-r from-blue-400 to-violet-500 bg-clip-text text-transparent drop-shadow-[0_2px_3px_rgba(0,0,0,0.3)]">
                Digital Workflow
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-xl text-gray-100 mb-10 max-w-2xl drop-shadow-md"
            >
              The all-in-one workspace for teams to collaborate, manage projects, and boost productivity with AI-powered
              insights.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="flex flex-col sm:flex-row gap-4 mb-16"
            >
              <Link
                href="/signup"
                className="px-8 py-4 rounded-md text-base font-medium text-white bg-gradient-to-r from-blue-500 to-violet-500 hover:from-blue-600 hover:to-violet-600 transition-colors flex items-center justify-center group"
              >
                Get Started Free
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <button className="px-8 py-4 rounded-md text-base font-medium border border-white/10 text-white hover:bg-white/5 transition-colors">
                Watch Demo
              </button>
            </motion.div>

            {/* Update the "Experience the Future" section */}
            <motion.div
              initial={{ opacity: 0.95, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center mb-8 relative z-10"
            >
              <div className="absolute inset-0 bg-black/30 backdrop-blur-sm rounded-xl -z-10"></div>
              <h3 className="text-2xl md:text-3xl font-medium text-white py-4 px-6 drop-shadow-lg">
                Experience the{" "}
                <span className="bg-gradient-to-r from-blue-400 to-violet-500 bg-clip-text text-transparent font-bold">
                  Future of Productivity
                </span>
              </h3>
              <p className="text-gray-100 mt-2 max-w-2xl mx-auto pb-4 px-6 drop-shadow-md">
                Our intelligent workspace adapts to your team's unique workflow
              </p>
            </motion.div>

            {/* 3D Hero Visual */}
            <motion.div
              initial={{ opacity: 1, scale: 1 }} // Changed from animation to immediate visibility
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0 }} // Removed delay
              className="w-full max-w-5xl mx-auto h-[400px] md:h-[500px] relative"
              style={{ willChange: "transform" }}
            >
              <FloatingSpheres />
            </motion.div>
          </div>

          {/* Scroll Indicator */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2, duration: 0.8 }}
            className="absolute bottom-10 left-1/2 transform -translate-x-1/2"
          >
            <motion.div
              animate={{ y: [0, 10, 0] }}
              transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5 }}
              className="flex flex-col items-center"
            >
              <span className="text-white/50 text-sm mb-2">Scroll to explore</span>
              <div className="w-6 h-10 border-2 border-white/20 rounded-full flex justify-center">
                <motion.div
                  animate={{ y: [0, 15, 0] }}
                  transition={{ repeat: Number.POSITIVE_INFINITY, duration: 1.5 }}
                  className="w-1.5 h-1.5 bg-white rounded-full mt-2"
                />
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Trusted By Section */}
      <section className="py-16 border-y border-white/5 relative overflow-hidden">
        <div className="container mx-auto px-6">
          <div className="text-center text-xs text-gray-400 uppercase tracking-wider mb-8">
            TRUSTED BY INNOVATIVE COMPANIES
          </div>
          <div className="flex flex-wrap justify-center items-center gap-10 md:gap-16">
            {["Microsoft", "Airbnb", "Spotify", "Slack", "Uber"].map((company, index) => (
              <motion.div
                key={company}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="text-lg font-medium text-gray-300 opacity-60 hover:opacity-100 transition-opacity"
              >
                {company}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" ref={featuresRef} className="py-24 relative overflow-hidden">
        <div className="container mx-auto px-6 relative z-10">
          {/* Update the features section heading */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-block px-2.5 py-1 bg-white/10 backdrop-blur-md text-white rounded-md text-sm font-medium mb-4 border border-white/20">
              Features
            </div>
            <h2 className="text-4xl font-bold mb-4 text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]">
              Everything You Need in{" "}
              <span className="bg-gradient-to-r from-blue-400 to-violet-500 bg-clip-text text-transparent">
                One Place
              </span>
            </h2>
            <p className="text-lg text-gray-100 max-w-2xl mx-auto drop-shadow-md">
              Powerful tools to streamline your workflow and boost team productivity.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: "📊",
                title: "Advanced Analytics",
                description:
                  "Get real-time insights into your team's performance with detailed reports and interactive dashboards.",
                gradient: "from-blue-500 to-violet-500",
              },
              {
                icon: "🔄",
                title: "Seamless Integration",
                description: "Connect with your favorite tools and services for a unified workflow experience.",
                gradient: "from-cyan-500 to-blue-500",
              },
              {
                icon: "📝",
                title: "Task Management",
                description: "Organize tasks, set priorities, and track progress with our intuitive interface.",
                gradient: "from-violet-500 to-fuchsia-500",
              },
              {
                icon: "👥",
                title: "Team Collaboration",
                description: "Work together seamlessly with real-time editing, comments, and notifications.",
                gradient: "from-blue-500 to-cyan-500",
              },
              {
                icon: "🔒",
                title: "Enterprise Security",
                description: "Keep your data safe with advanced security features and compliance standards.",
                gradient: "from-fuchsia-500 to-pink-500",
              },
              {
                icon: "📱",
                title: "Mobile Access",
                description: "Access your workspace from anywhere with our mobile apps for iOS and Android.",
                gradient: "from-violet-500 to-blue-500",
              },
            ].map((feature, index) => (
              // Update the feature cards for better text visibility
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -5, transition: { duration: 0.2 } }}
                className="bg-white/[0.05] backdrop-blur-md rounded-2xl p-8 border border-white/10 hover:border-white/20 transition-all relative overflow-hidden group"
              >
                <div className="absolute inset-0 bg-gradient-to-tr from-white/[0.05] to-transparent pointer-events-none" />
                <div
                  className="absolute -inset-0.5 bg-gradient-to-r opacity-0 group-hover:opacity-30 transition-opacity blur-xl"
                  style={{
                    backgroundImage: `linear-gradient(to right, var(--tw-gradient-stops))`,
                    "--tw-gradient-from": feature.gradient.split(" ")[0].replace("from-", ""),
                    "--tw-gradient-to": feature.gradient.split(" ")[1].replace("to-", ""),
                  }}
                />

                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center mb-5 text-xl bg-gradient-to-r ${feature.gradient} text-white shadow-lg`}
                >
                  {feature.icon}
                </div>
                <h3 className="text-lg font-semibold mb-3 text-white drop-shadow-sm">{feature.title}</h3>
                <p className="text-gray-200 text-[0.9375rem] leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Dashboard Preview Section */}
      <section id="showcase" className="py-20 relative overflow-hidden">
        <div className="container mx-auto px-6 relative z-10">
          {/* Update the dashboard section heading */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-block px-2.5 py-1 bg-white/10 backdrop-blur-md text-white rounded-md text-sm font-medium mb-4 border border-white/20">
              Dashboard
            </div>
            <h2 className="text-4xl font-bold mb-4 text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]">
              Powerful and{" "}
              <span className="bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent">
                Intuitive Interface
              </span>
            </h2>
            <p className="text-lg text-gray-100 max-w-2xl mx-auto drop-shadow-md">
              Customize your workspace to fit your unique workflow needs.
            </p>
          </motion.div>

          <div className="flex flex-col items-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
              className="flex gap-1 mb-6 bg-white/[0.03] backdrop-blur-md p-1 rounded-md border border-white/5"
            >
              <button className="px-6 py-3 rounded text-sm font-medium bg-white/10 text-white">Projects</button>
              <button className="px-6 py-3 rounded text-sm font-medium text-gray-300 hover:bg-white/5">Calendar</button>
              <button className="px-6 py-3 rounded text-sm font-medium text-gray-300 hover:bg-white/5">
                Analytics
              </button>
              <button className="px-6 py-3 rounded text-sm font-medium text-gray-300 hover:bg-white/5">Team</button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              viewport={{ once: true }}
              className="w-full max-w-5xl rounded-2xl overflow-hidden shadow-2xl border border-white/10 relative group"
            >
              <div className="absolute inset-0 bg-gradient-to-tr from-blue-500/20 to-violet-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <img
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/dashboard-taskboard-VWqtqUro0OopY9Ptu1cJ3rsD9hpvSt.png"
                alt="Integral Dashboard View"
                className="w-full transform transition-transform duration-700 group-hover:scale-[1.02]"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-24 border-y border-white/5 relative">
        <div className="absolute w-[30rem] h-[30rem] rounded-full bg-violet-500 filter blur-[100px] opacity-5 top-[-15rem] left-[-15rem] pointer-events-none"></div>

        <div className="container mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-white/[0.03] backdrop-blur-md rounded-[2rem] p-12 max-w-3xl mx-auto border border-white/5 relative overflow-hidden"
          >
            <div className="absolute inset-0 bg-gradient-to-tr from-white/[0.03] to-transparent pointer-events-none" />

            <p className="text-2xl font-medium text-white mb-8 leading-relaxed">
              "
              <span className="bg-gradient-to-r from-violet-400 to-fuchsia-500 bg-clip-text text-transparent">
                Integral
              </span>{" "}
              has completely transformed how our team works. The intuitive interface and powerful features have
              increased our productivity by 35% in just two months."
            </p>

            <div className="flex flex-col items-center">
              <div
                className="w-16 h-16 rounded-full overflow-hidden mb-4 border-2 border-transparent bg-white p-[2px]"
                style={{
                  backgroundImage:
                    "linear-gradient(white, white) padding-box, linear-gradient(135deg, #6366f1, #ec4899) border-box",
                }}
              >
                <img
                  src="/placeholder.svg?height=100&width=100"
                  alt="Sarah Johnson"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <div className="text-lg font-semibold text-white">Sarah Johnson</div>
              <div className="text-sm text-gray-400">Product Manager at Acme Inc.</div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" ref={pricingRef} className="py-24 relative overflow-hidden">
        <div className="absolute w-[30rem] h-[30rem] rounded-full bg-blue-500 filter blur-[100px] opacity-5 top-[-15rem] right-[-15rem] pointer-events-none"></div>
        <div className="absolute w-[30rem] h-[30rem] rounded-full bg-violet-500 filter blur-[100px] opacity-5 bottom-[-15rem] left-[-15rem] pointer-events-none"></div>

        <div className="container mx-auto px-6 relative z-10">
          {/* Update the pricing section heading */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <div className="inline-block px-2.5 py-1 bg-white/10 backdrop-blur-md text-white rounded-md text-sm font-medium mb-4 border border-white/20">
              Pricing
            </div>
            <h2 className="text-4xl font-bold mb-4 text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]">
              Choose Your{" "}
              <span className="bg-gradient-to-r from-blue-400 to-violet-500 bg-clip-text text-transparent">
                Perfect Plan
              </span>
            </h2>
            <p className="text-lg text-gray-100 max-w-2xl mx-auto drop-shadow-md">
              Flexible pricing options tailored to your needs with no hidden fees.
            </p>
          </motion.div>

          <div className="flex flex-col md:flex-row justify-center gap-8 items-stretch">
            {[
              {
                name: "Starter",
                price: "Free",
                period: "Forever free",
                features: ["Up to 3 team members", "5 projects", "Basic analytics", "24/7 support"],
                buttonText: "Get Started",
                buttonVariant: "outline",
                featured: false,
              },
              {
                name: "Pro",
                price: "₹49",
                period: "per user / month",
                features: ["Unlimited team members", "Unlimited projects", "Advanced analytics", "Priority support"],
                buttonText: "Start Free Trial",
                buttonVariant: "primary",
                featured: true,
              },
              {
                name: "Enterprise",
                price: "Custom",
                period: "Contact for pricing",
                features: [
                  "Everything in Pro",
                  "Custom integrations",
                  "Dedicated account manager",
                  "SLA & premium support",
                ],
                buttonText: "Contact Sales",
                buttonVariant: "outline",
                featured: false,
              },
            ].map((plan, index) => (
              // Update the pricing cards for better text visibility
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -10, transition: { duration: 0.2 } }}
                className={`bg-white/[0.07] backdrop-blur-md rounded-2xl p-8 w-full max-w-xs border ${plan.featured ? "border-violet-500/50 shadow-lg shadow-violet-500/20" : "border-white/10"} transition-all relative overflow-hidden`}
              >
                {plan.featured && (
                  <div className="absolute top-0 right-0">
                    <div className="bg-gradient-to-r from-blue-500 to-violet-500 text-white text-xs font-bold px-3 py-1 rounded-bl-lg rounded-tr-lg">
                      POPULAR
                    </div>
                  </div>
                )}

                <div className="absolute inset-0 bg-gradient-to-tr from-white/[0.05] to-transparent pointer-events-none" />

                <div className="mb-6">
                  <div className="text-lg font-semibold text-white mb-2">{plan.name}</div>
                  <div className="text-4xl font-bold text-white mb-2">{plan.price}</div>
                  <div className="text-sm text-gray-300">{plan.period}</div>
                </div>

                <div className="mb-8">
                  {plan.features.map((feature, i) => (
                    <div key={i} className="flex items-center mb-3 text-[0.9375rem] text-gray-200">
                      <Check className="mr-2 h-4 w-4 text-blue-400" />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>

                <button
                  className={`w-full py-3 px-4 rounded-md text-sm font-medium ${
                    plan.buttonVariant === "primary"
                      ? "bg-gradient-to-r from-blue-500 to-violet-500 hover:from-blue-600 hover:to-violet-600 text-white transition-colors shadow-md"
                      : "border border-white/20 text-white hover:bg-white/10 transition-colors"
                  }`}
                >
                  {plan.buttonText}
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section id="contact" className="py-20 relative overflow-hidden">
        <div className="absolute w-[30rem] h-[30rem] rounded-full bg-blue-500 filter blur-[100px] opacity-5 top-[-15rem] right-[-15rem] pointer-events-none"></div>

        <div className="container mx-auto px-6 relative z-10">
          {/* Update the CTA section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center relative"
          >
            <div className="absolute inset-0 bg-black/20 backdrop-blur-sm rounded-xl -z-10 mx-auto max-w-3xl"></div>
            <h2 className="text-4xl font-bold mb-4 text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)] pt-4">
              Ready to Transform Your{" "}
              <span className="bg-gradient-to-r from-blue-400 to-violet-500 bg-clip-text text-transparent">
                Workflow?
              </span>
            </h2>
            <p className="text-lg text-gray-100 max-w-2xl mx-auto mb-8 drop-shadow-md">
              Join thousands of teams already using Integral to boost their productivity.
            </p>
            <Link
              href="/signup"
              className="inline-block px-8 py-4 rounded-md text-base font-medium text-white bg-gradient-to-r from-blue-500 to-violet-500 hover:from-blue-600 hover:to-violet-600 transition-colors group shadow-lg mb-4"
            >
              Get Started Today
              <ChevronRight className="inline-block ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      {/* Update the footer for better text visibility */}
      <footer className="bg-black/70 backdrop-blur-md py-16 border-t border-white/10">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
            <div className="col-span-1 lg:col-span-1">
              <div className="mb-4">
                <div className="text-2xl font-light text-white">
                  <span className="bg-gradient-to-r from-blue-400 to-violet-500 bg-clip-text text-transparent">
                    integral
                  </span>
                </div>
              </div>
              <p className="text-gray-300 text-sm mb-6">
                The all-in-one workspace for teams to collaborate, manage projects, and boost productivity.
              </p>
              <div className="flex gap-4">
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  <Twitter size={18} />
                </a>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  <Linkedin size={18} />
                </a>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  <Github size={18} />
                </a>
                <a href="#" className="text-gray-300 hover:text-white transition-colors">
                  <Instagram size={18} />
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Product</h4>
              <div className="flex flex-col gap-2">
                <a href="#" className="text-gray-300 text-sm hover:text-white transition-colors">
                  Features
                </a>
                <a href="#" className="text-gray-300 text-sm hover:text-white transition-colors">
                  Pricing
                </a>
                <a href="#" className="text-gray-300 text-sm hover:text-white transition-colors">
                  Integrations
                </a>
                <a href="#" className="text-gray-300 text-sm hover:text-white transition-colors">
                  Changelog
                </a>
                <a href="#" className="text-gray-300 text-sm hover:text-white transition-colors">
                  Roadmap
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Resources</h4>
              <div className="flex flex-col gap-2">
                <a href="#" className="text-gray-300 text-sm hover:text-white transition-colors">
                  Blog
                </a>
                <a href="#" className="text-gray-300 text-sm hover:text-white transition-colors">
                  Documentation
                </a>
                <a href="#" className="text-gray-300 text-sm hover:text-white transition-colors">
                  Guides
                </a>
                <a href="#" className="text-gray-300 text-sm hover:text-white transition-colors">
                  Webinars
                </a>
                <a href="#" className="text-gray-300 text-sm hover:text-white transition-colors">
                  Templates
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-white font-semibold mb-4">Company</h4>
              <div className="flex flex-col gap-2">
                <a href="#" className="text-gray-300 text-sm hover:text-white transition-colors">
                  About
                </a>
                <a href="#" className="text-gray-300 text-sm hover:text-white transition-colors">
                  Careers
                </a>
                <a href="#" className="text-gray-300 text-sm hover:text-white transition-colors">
                  Contact
                </a>
                <a href="#" className="text-gray-300 text-sm hover:text-white transition-colors">
                  Partners
                </a>
                <a href="#" className="text-gray-300 text-sm hover:text-white transition-colors">
                  Press
                </a>
              </div>
            </div>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center mt-12 pt-6 border-t border-white/10">
            <div className="text-gray-400 text-sm">© 2025 Integral. All rights reserved.</div>
            <div className="flex gap-4 mt-4 md:mt-0">
              <a href="#" className="text-gray-400 text-sm hover:text-white transition-colors">
                Privacy Policy
              </a>
              <a href="#" className="text-gray-400 text-sm hover:text-white transition-colors">
                Terms of Service
              </a>
              <a href="#" className="text-gray-400 text-sm hover:text-white transition-colors">
                Security
              </a>
            </div>
          </div>
        </div>
      </footer>
    </>
  )
}

// This file provides a service for syncing between tasks and calendar
// without creating circular dependencies or violating React hook rules

type CalendarCallbacks = {
  addEvent: (event: any) => any
  updateEvent: (id: string, updates: any) => void
  deleteEvent: (id: string) => void
}

type TaskCallbacks = {
  updateTaskFromCalendar: (eventId: string, updates: any) => void
}

// Singleton service to manage communication between contexts
class SyncService {
  private static instance: SyncService
  private calendarCallbacks: CalendarCallbacks | null = null
  private taskCallbacks: TaskCallbacks | null = null
  private pendingTasksToSync: any[] = []

  private constructor() {}

  public static getInstance(): SyncService {
    if (!SyncService.instance) {
      SyncService.instance = new SyncService()
    }
    return SyncService.instance
  }

  // Register calendar functions that tasks can call
  public registerCalendarCallbacks(callbacks: CalendarCallbacks): void {
    this.calendarCallbacks = callbacks

    // Process any pending tasks that were waiting for calendar callbacks
    if (this.pendingTasksToSync.length > 0 && callbacks.addEvent) {
      this.pendingTasksToSync.forEach((task) => {
        this.syncTaskToCalendar(task)
      })
      this.pendingTasksToSync = []
    }
  }

  // Register task functions that calendar can call
  public registerTaskCallbacks(callbacks: TaskCallbacks): void {
    this.taskCallbacks = callbacks
  }

  // Convert a task to calendar event format
  public taskToCalendarEvent(task: any): any {
    if (!task.dueDate) return null

    return {
      id: `task-${task.id}`,
      title: task.text,
      date: task.dueDate,
      startTime: "09:00", // Default time
      endTime: "10:00", // Default time
      type: "task",
      completed: task.completed,
      priority: task.priority,
      description: `${task.priority ? task.priority.toUpperCase() + " priority" : ""} ${task.category} task`,
    }
  }

  // Sync a task to the calendar
  public syncTaskToCalendar(task: any): void {
    if (!task.addedToCalendar || !task.dueDate) {
      return
    }

    if (!this.calendarCallbacks) {
      // Store task for later processing when calendar is available
      this.pendingTasksToSync.push(task)
      return
    }

    const eventData = this.taskToCalendarEvent(task)
    if (!eventData) return

    const existingEventId = `task-${task.id}`

    if (task.calendarEventId) {
      // Update existing event
      if (this.calendarCallbacks.updateEvent) {
        this.calendarCallbacks.updateEvent(task.calendarEventId, eventData)
      }
      return { success: true, eventId: task.calendarEventId }
    } else {
      // Add new event
      if (this.calendarCallbacks.addEvent) {
        const newEvent = this.calendarCallbacks.addEvent(eventData)
        return { success: true, eventId: newEvent.id }
      }
    }

    return { success: false }
  }

  // Remove a task from the calendar
  public removeTaskFromCalendar(task: any): void {
    if (!this.calendarCallbacks) return

    if (task.calendarEventId && this.calendarCallbacks.deleteEvent) {
      this.calendarCallbacks.deleteEvent(task.calendarEventId)
    } else if (this.calendarCallbacks.deleteEvent) {
      // Try with the standard task id pattern
      this.calendarCallbacks.deleteEvent(`task-${task.id}`)
    }
  }

  // Update a task from calendar changes
  public updateTaskFromCalendar(eventId: string, eventUpdates: any): void {
    if (!this.taskCallbacks) return

    // Extract task ID from event ID (if it's a task-generated event)
    const taskIdMatch = eventId.match(/^task-(.+)$/)
    if (!taskIdMatch) return

    this.taskCallbacks.updateTaskFromCalendar(eventId, eventUpdates)
  }
}

export const syncService = SyncService.getInstance()
